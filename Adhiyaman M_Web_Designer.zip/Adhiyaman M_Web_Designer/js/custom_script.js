$(document).ready(function(){
    $(".hamburger_menu").click(function(){
        if($(this).hasClass("menuactive")){
            $(".hamburger_menu").removeClass("menuactive")
            $(".hamburger_menu").siblings("ul").hide();
            
        }
        else{
            $(".hamburger_menu").addClass("menuactive")
            $(".hamburger_menu").siblings("ul").show(); 
        }

    });
    $(".nav_domain_tool").click(function(){
        $(".tools_data").removeClass("tool_active")
        $(".domain-tools").addClass("tool_active")
    });
    $(".nav_sysadmin_tool").click(function(){
        $(".tools_data").removeClass("tool_active")
        $(".sysadmin__tools").addClass("tool_active")
    })
    $(".category__nav li a").click(function(){
        $(".category__nav li a").removeClass("active");
        $(this).addClass("active");

    });
    
})