$(document).ready(function(){
    alert("0");
})